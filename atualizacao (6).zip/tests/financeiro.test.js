import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  consolidarSaldos, disponivelConta, resultadoCaixaDia, liquidoEntrada, inadimplencia,
  aReceberPorJanela, projecaoCaixa, cobertura, capitalDeGiro, situacaoDia,
  ehGerenteFinanceiro, operaFinanceiro, configuraFinanceiro,
} from '../lib/financeiro.js';

test('saldo consolidado: soma por conta, disponível desconta o bloqueado', () => {
  const t = consolidarSaldos([
    { saldo_inicial: 1000, entradas: 500, saidas: 200, saldo_final: 1300, bloqueado: 100 },
    { saldo_inicial: 0, entradas: 0, saidas: 0, saldo_final: 400, bloqueado: 0 },
  ]);
  assert.equal(t.saldoFinal, 1700); assert.equal(t.bloqueado, 100); assert.equal(t.disponivel, 1600);
  assert.equal(disponivelConta({ saldo_final: 1300, bloqueado: 100 }), 1200);
  assert.equal(consolidarSaldos([]).disponivel, 0); // sem contas não quebra
});

test('resultado de caixa do dia e líquido da entrada', () => {
  assert.equal(resultadoCaixaDia(5000, 3200), 1800);
  assert.equal(resultadoCaixaDia(0, 500), -500);
  assert.equal(liquidoEntrada(1000, 43.9), 956.1); // desconta a taxa, arredonda em centavos
});

test('inadimplência: soma faixas e taxa = vencido ÷ base', () => {
  const i = inadimplencia({ inad_1_7: 100, inad_8_30: 200, inad_31_60: 0, inad_61_90: 0, inad_mais90: 700, inad_clientes: 5, recebido30: 9000 });
  assert.equal(i.vencido, 1000); assert.equal(i.clientes, 5);
  assert.equal(i.taxa, 0.1); // 1000 / (1000 + 9000)
  assert.equal(inadimplencia({}).taxa, null); // sem base não quebra
});

test('a receber por janela: total futuro ignora hoje e vencido', () => {
  const r = aReceberPorJanela({ receber_hoje: 100, receber_7: 300, receber_30: 1000, receber_60: 500, receber_90: 200, receber_mais90: 50, receber_vencido: 400 });
  assert.equal(r.futuroTotal, 300 + 1000 + 500 + 200 + 50);
  assert.equal(r.vencido, 400);
});

test('projeção de caixa: contratado ignora boleto, provável aplica probabilidade, aponta risco', () => {
  const p = projecaoCaixa({
    disponivel: 1000,
    aReceber: { sete: 500, trinta: 2000, sessenta: 0, noventa: 0 },
    boletoPorJanela: { sete: 0, trinta: 1000, sessenta: 0, noventa: 0 },
    inadRecuperavel: 0,
    aPagar: { sete: 2000, trinta: 1500, sessenta: 0, noventa: 0 },
    probBoleto: 0.8, probInad: 0,
  });
  // contratado em 7 dias: 1000 + 500 - 2000 = -500 (negativo => risco em "sete")
  assert.equal(p.contratado[0].saldo, -500);
  // provável em 30 dias inclui 80% do boleto de 1000: passo a passo
  // sete: 1000+500-2000=-500 ; trinta: -500 + (2000-1000+800) -1500 = -500 + 1800 -1500 = -200
  assert.equal(p.provavel[0].saldo, -500);
  assert.equal(p.provavel[1].saldo, -200);
  assert.equal(p.janelaRisco, 'sete');
  assert.equal(p.menorSaldo, -500);
});

test('cobertura e capital de giro', () => {
  assert.equal(cobertura(1000, 2000, 1500), 2); // (1000+2000)/1500
  assert.equal(cobertura(1000, 0, 0), null); // pagamentos zero => sem dado
  assert.equal(capitalDeGiro(5000, 2000, 1000), 2000); // falta 2000
  assert.equal(capitalDeGiro(1000, 2000, 1000), 0); // sobra => 0, nunca negativo
});

test('semáforo do dia: vermelho se falta caixa hoje ou há divergência', () => {
  assert.equal(situacaoDia({ disponivel: 1000, aPagarHoje: 1200 }), 'vermelho');
  assert.equal(situacaoDia({ disponivel: 1000, aPagarHoje: 0, divergencia: 50 }), 'vermelho');
  assert.equal(situacaoDia({ disponivel: 1000, aPagarHoje: 0, resultadoDia: -100 }), 'amarelo');
  assert.equal(situacaoDia({ disponivel: 1000, aPagarHoje: 500, resultadoDia: 200 }), 'verde');
});

test('permissões do financeiro', () => {
  const oper = { papel: 'colaborador', lotacoes: [{ setor: 'financeiro', subsetor: 'operacao' }] };
  const ger = { papel: 'gerente', lotacoes: [{ setor: 'financeiro', gerente: true }] };
  const dir = { papel: 'diretoria', lotacoes: [] };
  const outro = { papel: 'colaborador', lotacoes: [{ setor: 'marketing' }] };
  assert.equal(operaFinanceiro(oper), true);
  assert.equal(ehGerenteFinanceiro(oper), false);
  assert.equal(ehGerenteFinanceiro(ger), true);
  assert.equal(ehGerenteFinanceiro(dir), true);
  assert.equal(configuraFinanceiro(ger), true);
  assert.equal(configuraFinanceiro(oper), false);
  assert.equal(operaFinanceiro(outro), false);
});

import { lerFechamentoFinanceiro } from '../lib/leitoresFinanceiro.js';

function form(obj) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(obj)) { if (Array.isArray(v)) v.forEach((x) => fd.append(k, x)); else fd.set(k, v); }
  return fd;
}
const CTX = { hoje: '2026-09-18', janelaDias: 7, contas: new Set([1, 2]), produtos: new Set([9]), categorias: new Set([3]), centros: new Set([4]), fornecedores: new Set([5]), usuarios: new Set([7]) };
const base = { data_ref: '2026-09-18', status: 'conferido', divergencia_valor: '0', risco: '' };

test('leitor: saldo final é calculado (inicial + entradas - saídas)', () => {
  const fd = form({ ...base, saldo_conta: '1', sc1_saldo_inicial: '1.000,00', sc1_entradas: '500', sc1_saidas: '200', sc1_bloqueado: '0' });
  const r = lerFechamentoFinanceiro(fd, CTX);
  assert.equal(r.saldos[0].saldo_final, 1300);
});

test('leitor: data futura e fora da janela de 7 dias são recusadas', () => {
  assert.throws(() => lerFechamentoFinanceiro(form({ ...base, data_ref: '2026-09-20' }), CTX), /futuro/);
  assert.throws(() => lerFechamentoFinanceiro(form({ ...base, data_ref: '2026-09-01' }), CTX), /7 dias/);
});

test('leitor: entrada calcula líquido e recusa taxa maior que o bruto', () => {
  const ok = lerFechamentoFinanceiro(form({ ...base, ent_idx: '0', ent0_tipo: 'pix', ent0_valor_bruto: '1000', ent0_taxa: '30' }), CTX);
  assert.equal(ok.entradas[0].valor_liquido, 970);
  assert.throws(() => lerFechamentoFinanceiro(form({ ...base, ent_idx: '0', ent0_tipo: 'cartao', ent0_valor_bruto: '100', ent0_taxa: '150' }), CTX), /taxa/);
});

test('leitor: pagamento pago exige valor; previsto OU pago é obrigatório', () => {
  assert.throws(() => lerFechamentoFinanceiro(form({ ...base, pag_idx: '0', pag0_descricao: 'Luz', pag0_status: 'pago', pag0_valor_pago: '0', pag0_valor_previsto: '0' }), CTX), /valor pago/);
  const ok = lerFechamentoFinanceiro(form({ ...base, pag_idx: '0', pag0_descricao: 'Aluguel', pag0_status: 'previsto', pag0_valor_previsto: '2500', pag0_vencimento: '2026-09-25' }), CTX);
  assert.equal(ok.pagamentos[0].valor_previsto, 2500);
});

test('leitor: divergência > 0 exige motivo, ação, responsável e prazo; fechar exige conciliação', () => {
  assert.throws(() => lerFechamentoFinanceiro(form({ ...base, divergencia_valor: '50' }), CTX), /responsável|Preencha/);
  const ok = lerFechamentoFinanceiro(form({ ...base, divergencia_valor: '50', divergencia_motivo: 'Diferença no cartão', divergencia_acao: 'Conferir extrato', divergencia_responsavel_id: '7', divergencia_prazo: '2026-09-19' }), CTX);
  assert.equal(ok.cabecalho.divergencia_responsavel_id, 7);
  assert.throws(() => lerFechamentoFinanceiro(form({ ...base, status: 'fechado', bancos_conciliados: 'nao' }), CTX), /conciliados/);
});

import { montarDRE, pontoEquilibrio, cac, margemProduto, ratearPorReceita } from '../lib/financeiro.js';

test('DRE gerencial: receita líquida, margem de contribuição, EBITDA e resultado', () => {
  const d = montarDRE({ receitaBruta: 100000, taxas: 3000, impostos: 7000, custosVariaveis: 20000, marketing: 10000, custosFixos: 25000, pessoal: 15000, depreciacao: 2000, juros: 1000 });
  assert.equal(d.deducoes, 10000);
  assert.equal(d.receitaLiquida, 90000);
  assert.equal(d.variaveis, 30000);
  assert.equal(d.margemContribuicao, 60000);
  assert.equal(d.margemPct, 60000 / 90000); // ~0,667
  assert.equal(d.fixos, 40000);
  assert.equal(d.ebitda, 20000);
  assert.equal(d.resultado, 17000); // 20000 - 2000 - 1000
});

test('DRE sem receita não quebra (margem = sem dados)', () => {
  const d = montarDRE({});
  assert.equal(d.receitaLiquida, 0);
  assert.equal(d.margemPct, null);
  assert.equal(d.resultado, 0);
});

test('ponto de equilíbrio = custos fixos ÷ margem de contribuição %', () => {
  assert.equal(pontoEquilibrio(40000, 0.5), 80000);
  assert.equal(pontoEquilibrio(40000, 0), null); // margem zero/negativa => sem equilíbrio
  assert.equal(pontoEquilibrio(40000, null), null);
});

test('CAC e margem por produto', () => {
  assert.equal(cac(10000, 25), 400);
  assert.equal(cac(10000, 0), null);
  const m = margemProduto(5000, 3500);
  assert.equal(m.margem, 1500);
  assert.equal(m.pct, 0.3);
});

test('rateio de custo indireto pela participação na receita', () => {
  const r = ratearPorReceita(1000, [{ id: 1, receita: 7000 }, { id: 2, receita: 3000 }]);
  assert.deepEqual(r, [{ id: 1, rateio: 700 }, { id: 2, rateio: 300 }]);
  assert.deepEqual(ratearPorReceita(1000, [{ id: 1, receita: 0 }]), [{ id: 1, rateio: 0 }]); // sem receita não quebra
});

import { saldoDevedorTotal, parcelaMensalTotal, jurosMes, patrimonioTotal, patrimonioLiquido, grauEndividamento, progressoDivida, alcadaExcedida, capitalLiquido } from '../lib/financeiro.js';

test('dívidas: saldo, parcela mensal e juros do mês (só as em aberto)', () => {
  const ds = [
    { status: 'ativa', saldo_devedor: 50000, parcela_valor: 2000, taxa_mensal: 0.02 },
    { status: 'atrasada', saldo_devedor: 10000, parcela_valor: 800, taxa_mensal: 0.05 },
    { status: 'quitada', saldo_devedor: 0, parcela_valor: 0, taxa_mensal: 0.02 },
  ];
  assert.equal(saldoDevedorTotal(ds), 60000);
  assert.equal(jurosMes(ds), 50000 * 0.02 + 10000 * 0.05); // 1500
  assert.equal(parcelaMensalTotal(ds, [{ status: 'ativo', parcela_valor: 1200 }]), 2000 + 800 + 1200);
});

test('patrimônio líquido e grau de endividamento', () => {
  const ativos = [{ valor_atual: 200000 }, { valor_atual: 50000 }];
  const dividas = [{ status: 'ativa', saldo_devedor: 60000 }];
  assert.equal(patrimonioTotal(ativos), 250000);
  assert.equal(patrimonioLiquido(ativos, dividas), 190000);
  assert.equal(grauEndividamento(dividas, ativos), 60000 / 250000);
  assert.equal(grauEndividamento(dividas, []), null); // sem ativos não quebra
});

test('progresso, alçada e capital líquido', () => {
  assert.equal(progressoDivida(12, 48), 0.25);
  assert.equal(alcadaExcedida(15000, 10000), true);
  assert.equal(alcadaExcedida(8000, 10000), false);
  assert.equal(alcadaExcedida(15000, 0), false); // sem limite configurado não trava
  assert.equal(capitalLiquido([{ tipo: 'aporte', valor: 50000 }, { tipo: 'retirada', valor: 10000 }, { tipo: 'distribuicao', valor: 5000 }]), 35000);
});
